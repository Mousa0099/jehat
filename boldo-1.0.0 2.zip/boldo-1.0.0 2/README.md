## fotogency, a theme by ThemeWagon team.

---

Thank you for using Fotogency See the "public" folder, you will find everything ready to use there. If you want to use the gulp based workflow, cd to this directory in your terminal and run this command: npm i && gulp
Get the figma design file here:

<!-- [https://www.figma.com/community/file/iVtJJapAlfDQJLcDedSwMm] -->
